package assgnmt5Car;

public class Main {

    static final String DATA_FILE = "carData.txt";


    public static void main(String[] args) {
        readDataFromFile();
        //do forever loop
    }

    public static void readDataFromFile(String[] args) {

    }
}
