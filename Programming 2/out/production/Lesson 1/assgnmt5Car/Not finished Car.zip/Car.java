package assgnmt5Car;

import java.util.Scanner;

public class Car {
    private String makeModel;
    private int yearOfProd;
    private int engSizeL;
    Scanner scanner = new Scanner(System.in);

    public Car(String makeModel, int yearOfProd, int engSizeL) {
        this.makeModel = makeModel;
        this.yearOfProd = yearOfProd;
        this.engSizeL = engSizeL;
    }

    public String getMakeModel() {
        return makeModel;
    }

    public void setMakeModel(String makeModel) {
        while (makeModel.length()<2){
            System.out.println("Make model has to be at least 2 characters long");
        }
    }

    public int getYearOfProd() {
        return yearOfProd;
    }

    public void setYearOfProd(int yearOfProd) {
        while (yearOfProd < 1900 || yearOfProd > 2100) {
            System.out.println("Year of production must be between 1900-2100");
            yearOfProd = scanner.nextInt();
        }
    }
        public int getEngSizeL() {
            return engSizeL;
        }

        public void setEngSizeL ( int engSizeL){
            while (engSizeL < 0 || engSizeL>10)
            {
                System.out.println("The size of the engine must be between 1-10L ");
            }

        }
    }
